// pages/api/biens.js
import clientPromise from '../../lib/mongodb'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', true)
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT')
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  )

  if (req.method === 'OPTIONS') {
    res.status(200).end()
    return
  }

  try {
    const client = await clientPromise
    const db = client.db('test')
    
    const { 
      status = 'disponible',
      triPar = 'croissant', 
      page = 1, 
      pageSize = 6,
      typeBien,
      budgets,
      localisation,
      superficie
    } = req.query

    let filter = {}
    
    if (status) {
      filter.status = status
    }
    
    if (typeBien && typeBien !== 'tous') {
      filter.type = typeBien
    }
    
    if (budgets) {
      filter.prix = { $lte: parseInt(budgets) }
    }
    
    if (localisation) {
      filter.localisation = { $regex: localisation, $options: 'i' }
    }
    
    if (superficie) {
      filter['caracteristiques'] = { $regex: `${superficie}m²`, $options: 'i' }
    }

    const sort = triPar === 'croissant' ? { createdAt: 1 } : { createdAt: -1 }
    const skip = (parseInt(page) - 1) * parseInt(pageSize)
    const limit = parseInt(pageSize)

    const biens = await db
      .collection('biens')
      .find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .toArray()

    const total = await db.collection('biens').countDocuments(filter)
    const hasMore = skip + biens.length < total

    res.status(200).json({
      biens,
      hasMore,
      total,
      page: parseInt(page),
      pageSize: parseInt(pageSize)
    })
  } catch (error) {
    console.error('MongoDB Error:', error)
    res.status(500).json({ error: 'Erreur lors de la récupération des biens', details: error.message })
  }
}
