// pages/api/bien/[ref].js
import clientPromise from '../../../lib/mongodb'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', true)
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS')
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  )

  if (req.method === 'OPTIONS') {
    res.status(200).end()
    return
  }

  const { ref } = req.query

  try {
    const client = await clientPromise
    const db = client.db('test')
    
    const bien = await db.collection('biens').findOne({ ref })

    if (!bien) {
      return res.status(404).json({ error: 'Bien non trouvé' })
    }

    res.status(200).json(bien)
  } catch (error) {
    console.error('MongoDB Error:', error)
    res.status(500).json({ error: 'Erreur lors de la récupération du bien', details: error.message })
  }
}
