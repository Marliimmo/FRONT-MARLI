// pages/api/reviews.js
import clientPromise from '../../lib/mongodb'

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', true)
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,POST')
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  )

  if (req.method === 'OPTIONS') {
    res.status(200).end()
    return
  }

  try {
    const client = await clientPromise
    const db = client.db('test')

    if (req.method === 'GET') {
      const reviews = await db
        .collection('useravis')
        .find({})
        .sort({ createdAt: -1 })
        .toArray()

      res.status(200).json(reviews)
    } else if (req.method === 'POST') {
      const newReview = req.body
      const result = await db.collection('useravis').insertOne({
        ...newReview,
        createdAt: new Date()
      })

      res.status(201).json({ message: 'Avis ajouté avec succès', id: result.insertedId })
    } else {
      res.status(405).json({ error: 'Méthode non autorisée' })
    }
  } catch (error) {
    console.error('MongoDB Error:', error)
    res.status(500).json({ error: 'Erreur lors de la gestion des avis', details: error.message })
  }
}
